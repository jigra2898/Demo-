# asp_project
This is simple CRUD operation project with ASP.net and angular.js.
